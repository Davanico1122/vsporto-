# Portfolio Website

## Overview

This is a modern, full-stack portfolio website built with React, TypeScript, and Express.js. The application features a sleek, responsive design with glassmorphism effects, smooth animations, and a comprehensive content management system. It showcases projects, skills, and provides contact functionality with a professional admin panel for content management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **UI Components**: Radix UI primitives with custom shadcn/ui components
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Animations**: Framer Motion for smooth animations and micro-interactions

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **API**: RESTful API with Express routes
- **Development**: Hot module replacement with Vite middleware integration

### Design System
- **Theme**: Dark/light mode toggle with CSS custom properties
- **Visual Style**: Glassmorphism effects, gradient backgrounds, and modern UI
- **Typography**: Inter font family with JetBrains Mono for code
- **Responsive**: Mobile-first design with responsive breakpoints

## Key Components

### Database Schema
- **Users**: Authentication and admin management
- **Projects**: Portfolio project showcase with categories and featured flags
- **Skills**: Technical skills with proficiency levels and categories
- **Contacts**: Contact form submissions and inquiries
- **Blog Posts**: Content management for blog articles (optional)

### API Endpoints
- **GET /api/projects**: Retrieve all projects
- **GET /api/projects/featured**: Get featured projects only
- **GET /api/projects/:id**: Get specific project details
- **POST /api/projects**: Create new project (admin)
- **PUT /api/projects/:id**: Update project (admin)
- **DELETE /api/projects/:id**: Delete project (admin)
- **GET /api/skills**: Retrieve all skills
- **POST /api/contacts**: Submit contact form

### Routing
- **/** : Home page with all sections
- **/admin** : Admin panel for content management
- **/project/:id** : Individual project detail pages

### UI Components
- **Custom Cursor**: Interactive cursor with hover effects
- **Floating Navigation**: Smooth scrolling navigation dots
- **Project Modal**: Detailed project view with animations
- **Skill Bars**: Animated progress bars for skill levels
- **Theme Provider**: Dark/light mode management
- **Preloader**: Loading animation on initial page load

### Sections
- **Hero**: Main landing section with gradient backgrounds and animations
- **About**: Personal information, timeline, and GitHub stats
- **Skills**: Technical skills organized by categories
- **Projects**: Portfolio showcase with filtering, modals, and individual project pages
- **Contact**: Contact form with validation and submission
- **Project Detail**: Individual project pages accessible via `/project/:id` URLs

## Data Flow

1. **Client Request**: User navigates to website sections
2. **API Calls**: TanStack Query fetches data from Express API
3. **Database Query**: Drizzle ORM queries PostgreSQL database
4. **Response**: JSON data returned to client
5. **UI Update**: React components re-render with new data
6. **State Management**: TanStack Query caches and manages server state

### Admin Flow
1. **Authentication**: Admin login with credentials
2. **Content Management**: CRUD operations for projects and skills
3. **Real-time Updates**: Immediate UI updates after data changes
4. **Validation**: Zod schema validation for all form inputs

## External Dependencies

### Core Dependencies
- **@tanstack/react-query**: Server state management
- **drizzle-orm**: Type-safe database ORM
- **@neondatabase/serverless**: PostgreSQL database connection
- **framer-motion**: Animation library
- **wouter**: Lightweight routing
- **zod**: Runtime type validation

### UI Dependencies
- **@radix-ui/***: Accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe variant management
- **lucide-react**: Icon library

### Development Dependencies
- **typescript**: Type checking
- **vite**: Build tool and dev server
- **tsx**: TypeScript execution
- **esbuild**: Fast JavaScript bundler

## Deployment Strategy

### Production Build
1. **Frontend**: Vite builds React app to `dist/public`
2. **Backend**: esbuild bundles Express server to `dist/index.js`
3. **Database**: Drizzle migrations applied to PostgreSQL
4. **Assets**: Static files served from build directory

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string
- **NODE_ENV**: Environment mode (development/production)
- **Port**: Server port configuration

### Deployment Options
- **Vercel**: Recommended for full-stack deployment
- **Railway**: Alternative cloud platform
- **Self-hosted**: VPS with PM2 process manager

### Database Management
- **Migrations**: `npm run db:push` to sync schema
- **Schema**: Located in `shared/schema.ts`
- **Connection**: Serverless PostgreSQL via Neon

The application is designed to be production-ready with proper error handling, validation, and scalable architecture patterns.