import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Disable Vite HMR error overlay on mobile devices
if (typeof window !== "undefined" && /Mobi|Android/i.test(navigator.userAgent)) {
  // @ts-ignore
  if (window.__vite_plugin_react_preamble_installed__) {
    // @ts-ignore
    window.__vite_plugin_react_preamble_installed__ = false;
  }
}

createRoot(document.getElementById("root")!).render(<App />);
