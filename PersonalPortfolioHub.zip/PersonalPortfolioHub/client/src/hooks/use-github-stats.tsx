import { useQuery } from "@tanstack/react-query";

export function useGithubStats() {
  return useQuery({
    queryKey: ["/api/github-stats"],
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchInterval: 10 * 60 * 1000, // 10 minutes
  });
}
