import { motion, AnimatePresence } from "framer-motion";
import { X, Github, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface ProjectModalProps {
  project: any;
  onClose: () => void;
}

export function ProjectModal({ project, onClose }: ProjectModalProps) {
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[9999] bg-black/80 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.8, opacity: 0 }}
          className="relative max-w-4xl max-h-[90vh] w-full overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          <Card className="glass border-0">
            <CardHeader>
              <div className="flex justify-between items-start">
                <CardTitle className="text-3xl gradient-text">{project.title}</CardTitle>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className="glass hover:bg-white/20"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <img 
                src={project.image} 
                alt={project.title}
                className="w-full h-64 object-cover rounded-xl mb-6"
              />
              
              <p className="text-lg text-muted-foreground mb-6">
                {project.description}
              </p>
              
              <div className="mb-6">
                <h4 className="text-lg font-semibold mb-3">Technologies Used</h4>
                <div className="flex flex-wrap gap-2">
                  {project.technologies.map((tech: string) => (
                    <Badge key={tech} variant="secondary">
                      {tech}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <div className="flex space-x-4">
                <Button
                  onClick={() => window.open(project.github, "_blank")}
                  className="bg-primary hover:bg-primary/90 text-white"
                >
                  <Github className="w-4 h-4 mr-2" />
                  View Code
                </Button>
                <Button
                  onClick={() => window.open(project.demo, "_blank")}
                  variant="outline"
                  className="glass hover:bg-white/20"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Live Demo
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
