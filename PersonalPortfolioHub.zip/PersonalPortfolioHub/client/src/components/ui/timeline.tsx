import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";

interface TimelineItem {
  year: string;
  title: string;
  company: string;
  color: string;
}

interface TimelineProps {
  items: TimelineItem[];
}

export function Timeline({ items }: TimelineProps) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <div className="space-y-6" ref={ref}>
      {items.map((item, index) => (
        <motion.div
          key={index}
          className="timeline-item flex items-start space-x-4"
          initial={{ opacity: 0, x: -50 }}
          animate={isInView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.6, delay: index * 0.2 }}
        >
          <div className={`w-3 h-3 rounded-full mt-2 flex-shrink-0 ${
            item.color === "primary" ? "bg-primary" :
            item.color === "purple" ? "bg-purple-500" :
            item.color === "cyan" ? "bg-cyan-500" :
            "bg-primary"
          }`}></div>
          <div>
            <div className={`text-sm font-medium ${
              item.color === "primary" ? "text-primary" :
              item.color === "purple" ? "text-purple-400" :
              item.color === "cyan" ? "text-cyan-400" :
              "text-primary"
            }`}>
              {item.year}
            </div>
            <h4 className="text-lg font-semibold">{item.title}</h4>
            <p className="text-muted-foreground">{item.company}</p>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
