interface TechBadgeProps {
  name: string;
  icon: string;
  color: string;
}

export function TechBadge({ name, icon, color }: TechBadgeProps) {
  return (
    <div className="tech-badge glass px-4 py-2 rounded-full cursor-pointer">
      <i className={`${icon} ${color} mr-2`}></i>
      {name}
    </div>
  );
}
