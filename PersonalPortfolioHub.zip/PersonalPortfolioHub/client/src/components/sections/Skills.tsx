import { motion } from "framer-motion";
import { Code, Server, Settings, Award } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SkillBar } from "@/components/ui/skill-bar";
import { TechBadge } from "@/components/ui/tech-badge";
import { useQuery } from "@tanstack/react-query";
import { useInView } from "framer-motion";
import { useRef } from "react";

export function Skills() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const { data: skills = [] } = useQuery({
    queryKey: ["/api/skills"],
  });

  const skillCategories = [
    { name: "Frontend", icon: Code, color: "from-indigo-500 to-purple-600" },
    { name: "Backend", icon: Server, color: "from-emerald-500 to-teal-600" },
    { name: "DevOps", icon: Settings, color: "from-orange-500 to-red-600" },
  ];

  const technologies = [
    { name: "React", icon: "fab fa-react", color: "text-cyan-400" },
    { name: "Node.js", icon: "fab fa-node-js", color: "text-green-400" },
    { name: "Python", icon: "fab fa-python", color: "text-blue-400" },
    { name: "AWS", icon: "fab fa-aws", color: "text-orange-400" },
    { name: "Docker", icon: "fab fa-docker", color: "text-blue-400" },
    { name: "MongoDB", icon: "fas fa-database", color: "text-emerald-400" },
    { name: "Git", icon: "fab fa-git-alt", color: "text-red-400" },
    { name: "Figma", icon: "fab fa-figma", color: "text-purple-400" },
  ];

  const certifications = [
    { name: "AWS Certified Developer", provider: "Amazon", icon: "fab fa-aws" },
    { name: "Google Cloud Professional", provider: "Google", icon: "fab fa-google" },
    { name: "Microsoft Azure", provider: "Microsoft", icon: "fab fa-microsoft" },
  ];

  const getSkillsByCategory = (category: string) => {
    return skills.filter((skill: any) => skill.category === category.toLowerCase());
  };

  return (
    <section id="skills" className="py-20 relative" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 gradient-text">Skills & Expertise</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive skill set spanning frontend, backend, and modern development tools
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {skillCategories.map((category, index) => {
            const categorySkills = getSkillsByCategory(category.name);
            return (
              <motion.div
                key={category.name}
                initial={{ opacity: 0, y: 50 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: index * 0.2 }}
              >
                <Card className="glass border-0">
                  <CardHeader className="text-center">
                    <div className={`w-16 h-16 bg-gradient-to-r ${category.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                      <category.icon className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-xl">{category.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {categorySkills.map((skill: any) => (
                        <SkillBar
                          key={skill.id}
                          name={skill.name}
                          level={skill.level}
                          animate={isInView}
                        />
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Technology Badges */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <h3 className="text-2xl font-bold mb-8">Technologies I Work With</h3>
          <div className="flex flex-wrap justify-center gap-4">
            {technologies.map((tech, index) => (
              <motion.div
                key={tech.name}
                initial={{ opacity: 0, scale: 0 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.5, delay: 0.8 + index * 0.1 }}
              >
                <TechBadge name={tech.name} icon={tech.icon} color={tech.color} />
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Certifications */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.8 }}
        >
          <Card className="glass border-0">
            <CardHeader>
              <CardTitle className="text-2xl text-center flex items-center justify-center gap-2">
                <Award className="w-6 h-6" />
                Certifications
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {certifications.map((cert, index) => (
                  <motion.div
                    key={cert.name}
                    className="text-center"
                    initial={{ opacity: 0, y: 20 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.5, delay: 1 + index * 0.1 }}
                  >
                    <div className="w-16 h-16 bg-gradient-to-r from-primary to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className={`${cert.icon} text-white text-2xl`}></i>
                    </div>
                    <h4 className="font-semibold">{cert.name}</h4>
                    <p className="text-sm text-muted-foreground">{cert.provider}</p>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}
