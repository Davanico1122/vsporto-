import { motion } from "framer-motion";
import { Download, ExternalLink, MapPin, Calendar, Globe, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Timeline } from "@/components/ui/timeline";
import { useInView } from "framer-motion";
import { useRef } from "react";

export function About() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const { data: githubStats } = useQuery({
    queryKey: ["/api/github-stats"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const timelineData = [
    {
      year: "2023 - Present",
      title: "Senior Full Stack Developer",
      company: "TechCorp Inc.",
      color: "primary",
    },
    {
      year: "2021 - 2023",
      title: "Frontend Developer",
      company: "StartupXYZ",
      color: "purple",
    },
    {
      year: "2019 - 2021",
      title: "Junior Developer",
      company: "WebAgency",
      color: "cyan",
    },
  ];

  const personalInfo = [
    { icon: MapPin, label: "Location", value: "San Francisco, CA" },
    { icon: Calendar, label: "Experience", value: "5+ Years" },
    { icon: User, label: "Availability", value: "Available", color: "text-emerald-400" },
    { icon: Globe, label: "Languages", value: "EN, ES, FR" },
  ];

  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="about" className="py-20 relative" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 gradient-text">About Me</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Passionate developer with over 5 years of experience creating innovative digital solutions
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div 
            className="space-y-6"
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <Card className="glass border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  My Journey
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-6">
                  Started as a curious developer exploring web technologies, now specializing in full-stack development with a focus on React, Node.js, and modern design principles.
                </p>
                
                {/* GitHub Stats Widget */}
                {githubStats && (
                  <Card className="glass border-0">
                    <CardHeader>
                      <CardTitle className="text-lg">GitHub Activity</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center">
                          <div className="text-2xl font-bold text-primary">{githubStats.repositories}</div>
                          <div className="text-sm text-muted-foreground">Repositories</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-emerald-400">{githubStats.stars}</div>
                          <div className="text-sm text-muted-foreground">Stars</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-purple-400">{githubStats.followers}</div>
                          <div className="text-sm text-muted-foreground">Followers</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-cyan-400">{githubStats.following}</div>
                          <div className="text-sm text-muted-foreground">Following</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                className="bg-primary hover:bg-primary/90 text-white font-medium transition-all duration-300 hover:shadow-lg hover:shadow-primary/25"
              >
                <Download className="w-4 h-4 mr-2" />
                Download CV
              </Button>
              <Button 
                variant="outline"
                onClick={scrollToContact}
                className="glass hover:bg-white/20 font-medium transition-all duration-300"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Hire Me
              </Button>
            </div>
          </motion.div>

          <motion.div 
            className="space-y-6"
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            {/* Timeline */}
            <Card className="glass border-0">
              <CardHeader>
                <CardTitle>Experience Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <Timeline items={timelineData} />
              </CardContent>
            </Card>

            {/* Personal Info */}
            <Card className="glass border-0">
              <CardHeader>
                <CardTitle>Personal Info</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {personalInfo.map((info, index) => (
                    <div key={index}>
                      <div className="text-sm text-muted-foreground mb-1 flex items-center gap-2">
                        <info.icon className="w-4 h-4" />
                        {info.label}
                      </div>
                      <div className={`font-medium ${info.color || ""}`}>
                        {info.value}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
