import { Github, Linkedin, Twitter, Mail } from "lucide-react";

export function Footer() {
  const socialLinks = [
    { icon: Twitter, href: "https://twitter.com/johndoe", label: "Twitter" },
    { icon: Linkedin, href: "https://linkedin.com/in/johndoe", label: "LinkedIn" },
    { icon: Github, href: "https://github.com/johndoe", label: "GitHub" },
    { icon: Mail, href: "mailto:john@example.com", label: "Email" },
  ];

  return (
    <footer className="py-12 glass border-t border-white/10">
      <div className="container mx-auto px-4">
        <div className="text-center">
          <div className="text-3xl font-bold gradient-text mb-4">John Doe</div>
          <p className="text-muted-foreground mb-8">
            Full Stack Developer & Creative Designer
          </p>
          
          <div className="flex justify-center space-x-6 mb-8">
            {socialLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary transition-colors duration-200"
                aria-label={link.label}
              >
                <link.icon size={20} />
              </a>
            ))}
          </div>
          
          <div className="text-muted-foreground text-sm">
            © {new Date().getFullYear()} John Doe. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
}
