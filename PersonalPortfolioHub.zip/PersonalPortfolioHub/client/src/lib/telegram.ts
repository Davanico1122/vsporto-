export interface TelegramMessage {
  name: string;
  email: string;
  subject: string;
  message: string;
}

export async function sendTelegramMessage(data: TelegramMessage): Promise<boolean> {
  try {
    const response = await fetch("/api/contacts", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    return response.ok;
  } catch (error) {
    console.error("Failed to send message:", error);
    return false;
  }
}
